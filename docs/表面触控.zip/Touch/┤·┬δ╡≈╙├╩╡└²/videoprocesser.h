﻿#ifndef VIDEOPROCESSER_H
#define VIDEOPROCESSER_H


#include "TaskObject.h"
#include "queue.h"
#include "touchdata.h"


typedef enum {
    WORK_MODE_NONE = 0, //停止触屏工作模式
    WORK_MODE_CALIBRATE = 1, //启动触屏标定工作模式
    WORK_MODE_NORMAL = 2, //启动触屏识别模式
}WORK_MODE;

typedef Queue<cv::Mat> DataQueue;
class VideoProcesser : public QObject, public CTaskObjectLoop
{
    Q_OBJECT
public:
    explicit VideoProcesser(QObject *parent = nullptr);
    virtual ~VideoProcesser();


    virtual void Init();
    virtual void Processor(void * lpParam); //线程体函数 ，会一直循环  while(!stop){Processor();}
    virtual void Exit();


    bool PutData(cv::Mat &data);
    bool GetData(cv::Mat &data);


private:

    DataQueue m_queue{5};

    int       m_workMode{WORK_MODE_NONE};       //控制流标志
    int       m_index{0};                      //标定点序号，标定时要把第index点序号传进来


};

#endif // VIDEOPROCESSER_H
