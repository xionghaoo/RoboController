﻿#include "cameraobj.h"
#include <iostream>
CameraObj::CameraObj()
{

}

CameraObj::~CameraObj()
{

}

void CameraObj::Init()
{

}

void CameraObj::Processor(void *lpParam)
{
    while(!stop_)
    {
        if(capture_.isOpened())
        {
            cv::Mat frame;
            capture_ >> frame;
            if(!frame.empty() )
            {
                if(func_)
                    func_(frame);
            }


        }


    }

}

void CameraObj::Exit()
{

}

bool    CameraObj::Open()
{

    if(capture_.open(index_))
    {
        std::cout<<"open camera success "<<std::endl;
        capture_.set(cv::CAP_PROP_FRAME_WIDTH, width_);
        capture_.set(cv::CAP_PROP_FRAME_HEIGHT, height_);
        capture_.set(cv::CAP_PROP_FPS, frame_);
        stop_ = false;
        BeginTask(0);
        SetEvent();
        return true;
    }

    return false;

}

void    CameraObj::InitCamera(int camIndex,int width,int height,int frame,int exposure)
{

    index_ = camIndex;
    width_ = width;
    height_ = height;
    frame_ = frame;
    exposure_ = exposure;

}

void    CameraObj::ExitCamera()
{
    stop_ = true;
    EndTask();
    Close();

}



void    CameraObj::SetCallBack(VIDEO_CALLBACK f)
{
    func_ = f;
}

void    CameraObj::Close()
{
    capture_.release();
}


