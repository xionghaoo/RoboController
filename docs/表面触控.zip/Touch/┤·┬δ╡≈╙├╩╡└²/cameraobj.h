﻿#ifndef CAMERAOBJ_H
#define CAMERAOBJ_H

#include <string>
#include <functional>
#include <opencv2/videoio.hpp>
#include <opencv2/opencv.hpp>
#include "TaskObject.h"
typedef std::function<void( cv::Mat& image)> VIDEO_CALLBACK;

class  CameraObj : public CTaskObjectLoop
{
public:
    CameraObj();
    virtual ~CameraObj();

    virtual void Init();
    virtual void Processor(void *lpParam); //线程执行函数，读取摄像头数据
    virtual void Exit();

    void    InitCamera(int camIndex,int width,int height,int frame,int exposure);
    void    ExitCamera();

    void    SetCallBack(VIDEO_CALLBACK f);//回调函数，得到图像后分给处理线程

    bool    Open();
    void    Close();

private:
    cv::VideoCapture  capture_;
    int               index_{0};
    int               width_{640};
    int               height_{480};
    int               frame_{30};
    int               exposure_{-6};
    VIDEO_CALLBACK    func_{nullptr};
    bool              stop_{true};
};

#endif // CAMERAOBJ_H
