#ifndef MARKINGFORM_H
#define MARKINGFORM_H


#define BUTTON_NUM          4




class MarkingForm 
{
public:
    explicit MarkingForm();
   

    void CallBackFunc(int index ,int retCode);

};




#endif // MARKINGFORM_H
