﻿#include "markingform.h"

/******************************************************************************/
/*                                                                            */
/******************************************************************************/

MarkingForm::MarkingForm()
{
    

}





void MarkingForm::CallBackFunc(int index ,int code)
{
     switch (code) {
	
    //标定完成 可以使用
    case 1606:
    {
        //清除标定缓存
        //停止显示动画
        //设置 正常工作 模式

    }
        break;
	//显示采集动画，时间：300ms
    case 1600:
    {
    }
        break;

    //显示下一个点
    case 1:
    {
        if(index >= 0)
        {
            if( index == (BUTTON_NUM-1))	//4个点标定完成
            {
                //显示等待动画
            }

            else if( index >= 0)
            {
                //显示下一个标定点
            }

        }
    }
        break;

    case 2:
    {
		//显示错误信息，等待返回码 102
      
    }
        break;
		
    case 102:
    {
       //继续采集标定数据
    }
        break;
    
 
    //标定出现错误，退出整个流程
    case -1:
    {
    }
        break;


    default:
        break;
    }

}

