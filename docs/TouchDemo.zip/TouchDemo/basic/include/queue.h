#ifndef QUEUE_H
#define QUEUE_H
#include <atomic>
#include <condition_variable>
#include <functional>
#include <memory>
#include <mutex>
#include <queue>
template <class T>
class Queue {
public:
    Queue(const size_t maxSize = 0xffffff);

    bool push(T &&data);
    bool pop(T &data);
    bool pop(std::queue<T> &queue);

    size_t size();
    void   clear();
    void   quit(bool bQuit);
protected:
    std::queue<T> m_queue;
    typename std::queue<T>::size_type m_maxSize;

    std::mutex m_mutex;
    std::atomic_bool m_quit{false};
};


template <class T>
Queue<T>::Queue(size_t maxSize) :
        m_maxSize{maxSize} {
}

template <class T>
bool Queue<T>::push(T &&data) {
    std::unique_lock<std::mutex> lock(m_mutex);

    if ( !m_quit && m_queue.size() < m_maxSize) {
        m_queue.push(std::move(data));
        return true;
    }

    return false;
}


template <class T>
bool Queue<T>::pop(T &data) {
    std::unique_lock<std::mutex> lock(m_mutex);

    if (!m_quit && !m_queue.empty()) {
        data = std::move(m_queue.front());
        m_queue.pop();

        return true;
    }

    return false;
}

template <class T>
bool Queue<T>::pop(std::queue<T> &queue)
{
    std::unique_lock<std::mutex> lock(m_mutex);

    if (!m_quit && !m_queue.empty()) {
        queue = std::move(m_queue);
        return true;
    }

    return false;
}

 template <class T>
 size_t Queue<T>::size() {
     std::unique_lock<std::mutex> lock(m_mutex);
     return m_queue.size() ;
 }

template <class T>
void Queue<T>::quit(bool bQuit) {
    m_quit = bQuit;
}

template <class T>
void Queue<T>::clear()
{
    std::unique_lock<std::mutex> lock(m_mutex);

    if(!m_queue.empty())
    {
        std::queue<T> empty;
        swap(empty, m_queue);
    }
}



#endif // QUEUE_H
