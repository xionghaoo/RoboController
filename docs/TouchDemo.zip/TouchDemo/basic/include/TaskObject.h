﻿#ifndef TASKOBJECT_H
#define TASKOBJECT_H

#include <thread>
#include <mutex>
#include <condition_variable>
#include "objects.h"

class  CTaskObjectLoop
{
public:
    CTaskObjectLoop();
    virtual ~CTaskObjectLoop();

    virtual void Init() {}
    virtual void Processor(void *lpParam) {}
    virtual void Exit() {}

    void BeginTask(int nTime, void *lpParam = nullptr);
    void EndTask();

    void SetEvent();
    void ResetEvent();

    bool Stop();
    unsigned long int GetHandle();
    std::thread::id ThreadId() const;

protected:
    void SetStop();
    void ResetStop();

    static void TaskObjectFunc(void *lpParam);

private:
    std::thread             m_th;
    SemObj                  m_Semaphore;
    std::atomic_bool        m_Stop;
    void *                  m_LPParam{nullptr};
    int                     m_nTime;
};

/****************************************************************/
/*                                                              */
/****************************************************************/

class  CTaskObjectLoopTO
{

public:
    CTaskObjectLoopTO();
    virtual ~CTaskObjectLoopTO();

    void BeginTask(int nTime, void *lpParam = nullptr);
    void EndTask();
    void SetEvent();

    bool Stop();
    unsigned long int GetHandle();
    std::thread::id ThreadId() const;

    virtual void Init() {}
    virtual void Processor(void *lpParam) {}
    virtual void Exit() {}

protected:
    void SetStop();
    void ResetStop();

    static void TaskObjectFunc(void *lpParam);

private:
    std::thread         m_th;
    SemObj              m_Semaphore;
    std::atomic_bool    m_Stop;
    void *              m_LPParam{nullptr};
    int                 m_nTime;
};

#endif // TASKOBJECT_H
