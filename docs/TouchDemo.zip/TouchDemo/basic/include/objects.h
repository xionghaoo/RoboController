﻿#ifndef OBJECTS_H
#define OBJECTS_H

#include <mutex>
#include <condition_variable>
#include <atomic>


class   SemObj {
public:
    SemObj();
    ~SemObj();

    bool Wait(int nTime);
    void Post();
    void ReSet();

    void Exit();

private:
    std::mutex              m_mtx;
    std::condition_variable m_cv;
    std::atomic_long        m_lValue;
    std::atomic_bool        m_bExit;
};

class   EventObj {
public:
    EventObj(int nCount=5);
    ~EventObj();

    bool Wait(int nTime);
    void Post();
    void ReSet();
    void Exit();
private:

    std::mutex              m_mtx;
    std::condition_variable m_cv;
    std::atomic_long        m_lValue;
    std::atomic_bool        m_bExit;
    int                     m_nCount;
};



#endif // OBJECTS_H
