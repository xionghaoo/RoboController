﻿#include "videoprocesser.h"
#include "touchscreen.h"
#include <iostream>


VideoProcesser::VideoProcesser() 
{
}

VideoProcesser::~VideoProcesser()
{

}



void VideoProcesser::Init()
{

}


void VideoProcesser::Processor(void * lpParam)
{
    cv::Mat data;
    if(GetData(data))
    {
        switch (m_workMode) {
        case WORK_MODE_NONE:
            break;
        case WORK_MODE_CALIBRATE:
        {
            ProcessMarking(m_index,data);
        }

            break;
        case WORK_MODE_NORMAL:
        {
            PorcessTouchData(data);
        }

            break;
        default:
            break;
        }
    }

}

void VideoProcesser::Exit()
{


}



bool VideoProcesser::PutData(cv::Mat &data)
{
    bool ret = false;
    ret=m_queue.push(std::move(data));
    if(ret)
    {
        SetEvent();
    }
    return ret;

}

bool VideoProcesser::GetData(cv::Mat &data)
{
    return m_queue.pop(data);
}





