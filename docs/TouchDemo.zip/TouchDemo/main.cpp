#include "touchscreen.h"
#include "cameraobj.h"
#include "videoprocesser.h"
#include "markingform.h"
void InitPointsLeft(std::vector<MarkPoint>& markPoints)
{
 
    int pxWidth=1920,pxHeight=1080;

    MarkPoint markPoint[4];

    //（5.2%，9.2%），（5.2%，90.7%），（94.8%，9.2%），（94.8%，90.7%）
    markPoint[0] = MarkPoint(pxWidth*0.052, pxHeight*0.092);
    markPoint[1] = MarkPoint(pxWidth*0.052, pxHeight*0.907);
    markPoint[2] = MarkPoint(pxWidth*0.948, pxHeight*0.092);
    markPoint[3] = MarkPoint(pxWidth*0.948, pxHeight*0.907);

    for(int i = 0 ; i < 4 ; ++i)
    {
        markPoints.push_back(markPoint[i]);

    }
}


int main(int argc, char** argv)
{
    
    CameraObj camera;
    VideoProcesser processer;

    MarkingForm markingForm;

    std::vector<MarkPoint> markPoints;
    InitPointsLeft(markPoints);

    int pxWidth = 1920;
    int pxHeight = 1080;
     //触屏算法初始化
    InTouchParam param;
    param.m_pxWidth = pxWidth;
    param.m_pxHeight = pxHeight;
    param.m_dataPath ="/sdcard/Touch";
    //标定回调函数
    param.m_markCallBack = std::bind(&MarkingForm::CallBackFunc, &markingForm, std::placeholders::_1, std::placeholders::_2);
    param.m_markPoints = markPoints;
    int ret = InitTouchScreen(param);
    if(ret == -1612)
    {
        //
        std::cout<<"init fail"<<std::endl;
        return -1;
    }

    VIDEO_CALLBACK callback = std::bind(&VideoProcesser::PutData, &processer, std::placeholders::_1);
    camera.SetCallBack(callback);


    processer.BeginTask(-1,0);
    //打开摄像头
    camera.InitCamera(0,1920,1080,30,30);
    if(camera.Open())
    {

    }

     for(;;);



    return 0;

}
