﻿#ifndef VIDEOPROCESSER_H
#define VIDEOPROCESSER_H


#include "TaskObject.h"
#include "queue.h"
#include "opencv2/highgui.hpp"
typedef enum {
    WORK_MODE_NONE = 0, //停止触屏工作模式
    WORK_MODE_CALIBRATE = 1, //启动触屏标定工作模式
    WORK_MODE_NORMAL = 2, //启动触屏识别模式
}WORK_MODE;

typedef Queue<cv::Mat> DataQueue;
class VideoProcesser : public CTaskObjectLoop
{
public:
    explicit VideoProcesser();
    virtual ~VideoProcesser();

    virtual void Init();
    virtual void Processor(void * lpParam);
    virtual void Exit();


    bool PutData(cv::Mat &data);
    bool GetData(cv::Mat &data);


    void ChangeWorkMode(int mode){m_workMode = mode; } //外部类通过控制 WORKMOD 来切换状态

    void StartMarking(int index ){ m_index = index;}  //标定时要改变这个值 第一点 ：0 ，....，第四点 ：3
    

private:
    DataQueue m_queue{5};
    int       m_workMode{WORK_MODE_NONE};

    int       m_index{0};           //标定点序号
};

#endif // VIDEOPROCESSER_H
